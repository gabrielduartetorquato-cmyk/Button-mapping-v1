# Evade Dash Mapper

Projeto Android para um botão flutuante de touch que dispara uma sequência de gestos configuráveis.

## O que esta versão faz

- Botão flutuante na lateral da tela.
- Calibração por toque para salvar a posição do agachar e do emote 2.
- Primeiro toque no botão: executa a sequência.
- Segundo toque enquanto a sequência está em andamento: cancela a sequência.
- Usa Android Accessibility para realizar os toques.

## Gerar o APK pelo GitHub Actions

Este projeto já inclui `.github/workflows/build-apk.yml`.

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para o repositório.
3. Entre na aba **Actions**.
4. Abra **Build EvadeDashMapper APK**.
5. Toque em **Run workflow** para iniciar manualmente, ou faça um novo commit na branch `main`.
6. Quando terminar, abra a execução concluída.
7. Na seção **Artifacts**, baixe `EvadeDashMapper-debug-apk`.
8. Extraia o arquivo baixado e instale `app-debug.apk` no celular.

## Permissões usadas

O aplicativo declara o serviço de Acessibilidade e usa uma sobreposição de Acessibilidade para exibir o botão flutuante.

O projeto não tenta ocultar sua identidade, burlar o Play Protect ou contornar mecanismos de segurança.
