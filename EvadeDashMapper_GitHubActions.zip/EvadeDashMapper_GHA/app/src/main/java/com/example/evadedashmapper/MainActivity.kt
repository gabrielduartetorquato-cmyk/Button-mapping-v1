package com.example.evadedashmapper

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Evade Dash Mapper\\n\\nPrimeira versão"
            textSize = 22f
        }

        val info = TextView(this).apply {
            text = "\\n1. Ative o serviço de Acessibilidade.\\n" +
                    "2. Permita a sobreposição sobre outros apps.\\n" +
                    "3. Abra o Roblox/Evade.\\n" +
                    "4. Use o botão flutuante lateral.\\n\\n" +
                    "A posição do emote e do agachar será calibrável na próxima etapa."
            textSize = 16f
        }

        val accessibility = Button(this).apply {
            text = "Abrir Acessibilidade"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val overlay = Button(this).apply {
            text = "Permitir botão sobre outros apps"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }

        val start = Button(this).apply {
            text = "Iniciar botão flutuante"
            setOnClickListener {
                DashAccessibilityService.instance?.showOverlay()
            }
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(accessibility)
        layout.addView(overlay)
        layout.addView(start)

        setContentView(layout)
    }
}
