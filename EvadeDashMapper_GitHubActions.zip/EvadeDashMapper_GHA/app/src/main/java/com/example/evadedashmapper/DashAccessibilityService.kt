package com.example.evadedashmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class DashAccessibilityService : AccessibilityService() {
    companion object { var instance: DashAccessibilityService? = null }
    private val handler = Handler(Looper.getMainLooper())
    private var dashButton: TextView? = null
    private var calibrationOverlay: View? = null
    private var running = false
    private var step = 0
    private val prefs by lazy { getSharedPreferences("calibration", MODE_PRIVATE) }
    private var crouchX: Float get()=prefs.getFloat("cx",-1f) ; set(v)=prefs.edit().putFloat("cx",v).apply()
    private var crouchY: Float get()=prefs.getFloat("cy",-1f) ; set(v)=prefs.edit().putFloat("cy",v).apply()
    private var emoteX: Float get()=prefs.getFloat("ex",-1f) ; set(v)=prefs.edit().putFloat("ex",v).apply()
    private var emoteY: Float get()=prefs.getFloat("ey",-1f) ; set(v)=prefs.edit().putFloat("ey",v).apply()

    override fun onServiceConnected() {
    super.onServiceConnected()
    instance = this
}

override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}

override fun onInterrupt() {}

override fun onDestroy() {
    removeDash()
    removeCalibration()
    instance = null
    super.onDestroy()
}

    fun startCalibration(){
        removeDash(); removeCalibration(); step=0
        val v=object:View(this){
            override fun onTouchEvent(e:MotionEvent):Boolean{
                if(e.action!=MotionEvent.ACTION_UP)return true
                if(step==0){ crouchX=e.rawX;crouchY=e.rawY;step=1;Toast.makeText(context,"Agachar salvo. Agora toque no EMOTE 2.",Toast.LENGTH_SHORT).show() }
                else { emoteX=e.rawX;emoteY=e.rawY;Toast.makeText(context,"Calibração concluída!",Toast.LENGTH_SHORT).show();removeCalibration();showOverlay() }
                return true
            }
        }
        calibrationOverlay=v
        val lp=WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT)
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v,lp)
        Toast.makeText(this,"Toque no centro do botão de AGACHAR.",Toast.LENGTH_LONG).show()
    }

    fun showOverlay(){
        if(dashButton!=null)return
        if(crouchX<0||emoteX<0){Toast.makeText(this,"Calibre os controles primeiro.",Toast.LENGTH_SHORT).show();return}
        val b=TextView(this).apply{ text="DASH";textSize=14f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setBackgroundResource(R.drawable.button_bg);setOnClickListener{if(running)cancelDash()else startDash()} }
        val lp=WindowManager.LayoutParams(dp(64),dp(64),WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.END or Gravity.CENTER_VERTICAL;x=dp(12)}
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(b,lp);dashButton=b
    }
    private fun startDash(){
        running=true;dashButton?.alpha=.55f
        tap(crouchX,crouchY){if(!running)return@tap;handler.postDelayed({if(running)tap(emoteX,emoteY){}},80)}
    }
    private fun cancelDash(){running=false;handler.removeCallbacksAndMessages(null);dashButton?.alpha=1f}
    private fun tap(x:Float,y:Float,done:(()->Unit)?){
        val path=Path().apply{moveTo(x,y)}
        val g=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,35)).build()
        dispatchGesture(g,object:GestureResultCallback(){override fun onCompleted(g:GestureDescription?){done?.invoke()};override fun onCancelled(g:GestureDescription?){done?.invoke()}},null)
    }
    private fun removeDash(){dashButton?.let{runCatching{(getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)}};dashButton=null}
    private fun removeCalibration(){calibrationOverlay?.let{runCatching{(getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)}};calibrationOverlay=null}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).roundToInt()
}
